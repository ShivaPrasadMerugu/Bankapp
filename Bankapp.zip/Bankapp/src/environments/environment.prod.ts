export const environment = {
  production: true,
  firebaseAPIKey: 'AIzaSyDLaNC_H9iSG9-QwOOkgAuGsD_eq4zHguc'
};

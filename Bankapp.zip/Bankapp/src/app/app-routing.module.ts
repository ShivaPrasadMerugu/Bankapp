import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ContactusComponent } from './contactus/contactus.component';
import { EditaccountComponent } from './editaccount/editaccount.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { LoginComponent } from './login/login.component';
import { ManageaccountsComponent } from './manageaccounts/manageaccounts.component';
import { MinistatementComponent } from './ministatement/ministatement.component';
import { MyaccountComponent } from './myaccount/myaccount.component';
import { NewaccountComponent } from './newaccount/newaccount.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { ViewaccountComponent } from './viewaccount/viewaccount.component';

const routes: Routes = [
  { path: '',component:LoginComponent},
  { path: 'adminlogin',component:AdminloginComponent},
  { path: 'userlogin',component:UserloginComponent},
  { path: 'addaccount',component:NewaccountComponent},
  { path: 'manageaccounts',component:ManageaccountsComponent},
  { path: 'updateaccountinfo',component:EditaccountComponent},
  { path: 'viewaccountinfo',component:ViewaccountComponent},
  { path: 'transactions',component:TransactionsComponent},
  { path: 'fundtransfer',component:FundtransferComponent},
  { path: 'myaccount',component:MyaccountComponent},
  { path: 'ministatement',component:MinistatementComponent},
  { path: 'aboutus',component:AboutusComponent},
  { path: 'contactus',component:ContactusComponent},
  { path: 'notfound',component:PagenotfoundComponent},
  { path: '**',redirectTo:'/notfound'}
  // {
  //   path: 'login',
  //   loadChildren: () => import('./login/login.module').then(m => m.LoginModule)
  // },
  // { path: 'dashboard',canActivate:[AuthGuard],component:DashboardComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

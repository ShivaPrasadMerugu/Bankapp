import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, MinLengthValidator, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { account } from 'src/models/account.model';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-newaccount',
  templateUrl: './newaccount.component.html',
  styleUrls: ['./newaccount.component.css']
})
export class NewaccountComponent implements OnInit {
  newAccountForm:FormGroup;
  accountnbr :number = 0;
  submitted:boolean=false;
  isLoading:boolean = false;
  error:string = null;
  response:string;
  constructor(private bankservice:BankService, public router: Router,private authservice:AuthService) { }

  ngOnInit(): void {
    this.newAccountForm =new FormGroup({
      'password':new FormControl(null,Validators.required),
      'cword':new FormControl(null,Validators.required),
      'fname':new FormControl(null,Validators.required),
      'lname':new FormControl(null,Validators.required),
      'dob':new FormControl(null,Validators.required),
      'optgender':new FormControl(null,Validators.required),
      'acctype':new FormControl(null,Validators.required),
      'PAddrs':new FormControl(null,Validators.required),
      'CAddrs':new FormControl(null,Validators.required),
      'profession':new FormControl(null,Validators.required),
      'income':new FormControl(null,Validators.required),
      'email':new FormControl(null,Validators.required),
      'mobile':new FormControl(null,Validators.required)
    })
  }
  CreateAccount(accountform:account){
    this.submitted = true;
    if (!this.newAccountForm.valid){
      return;
    }
    this.isLoading = true;
    accountform.accnbr = this.generateAccountNbr();
    accountform.balance = 1000;
    this.response  = this.bankservice.addNewAccount(accountform);
    debugger;
    if (this.response === "success"){
    this.isLoading = false;
    // this.bankservice.addNewAccount(accountform).subscribe(resdata => {
    //   this.isLoading=false;
    
    // },
    // error => {
    //   console.log(error);
    //   this.error = 'An error occurred while processing your request';
    //   this.isLoading=false;
    // }
    // );
   this.authservice.isAdminLoggedin = true;
   const redirectUrl = '/manageaccounts';
   this.router.navigate([redirectUrl]);
   this.newAccountForm.reset();
  }
  else{
    this.error = 'An error occurred while processing your request';
    this.isLoading=false;
  }
  }
  generateAccountNbr(){
    let minm = 1000000000000000;
    let maxm = 9999999999999999;
    return this.accountnbr = Math.floor(Math
    .random() * (maxm - minm + 1)) + minm;
  }
 
}

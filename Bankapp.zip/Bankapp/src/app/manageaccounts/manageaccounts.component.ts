import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-manageaccounts',
  templateUrl: './manageaccounts.component.html',
  styleUrls: ['./manageaccounts.component.css']
})
export class ManageaccountsComponent implements OnInit {
  accounts =[];
  constructor(private bankservice:BankService, private router: Router,private authservice:AuthService) { }
  
  ngOnInit(): void {
    this.bankservice.getUserAccounts().subscribe((data :any)=>{
    this.accounts = data;
    this.authservice.isAdminLoggedin = true;
    console.log(this.accounts);
  });
  }
  ViewAccount(id:string){
    this.bankservice.viewAccount = id;
    const redirectUrl = '/viewaccountinfo';
    this.router.navigate([redirectUrl]);
  }
  editAccount(id:string){
    this.bankservice.viewAccount = id;
    const redirectUrl = '/updateaccountinfo';
    this.router.navigate([redirectUrl]);
  }
}

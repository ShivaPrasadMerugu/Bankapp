import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/services/auth.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  isAuthenticatedadmin = true;
  isAuthenticateduser = false;
  constructor(public authService: AuthService, private router:Router) { }

  ngOnInit(): void {
  }
  Logout(){
    this.authService.isAdminLoggedin = false;
    this.authService.isValidUser = false;
    localStorage.removeItem('usertoken');
    localStorage.removeItem('token');
    const redirectUrl = '/';
    this.router.navigate([redirectUrl]);
  }
}

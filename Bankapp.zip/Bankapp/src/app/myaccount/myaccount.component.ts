import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-myaccount',
  templateUrl: './myaccount.component.html',
  styleUrls: ['./myaccount.component.css']
})
export class MyaccountComponent implements OnInit {

  accounts :any;
  constructor(private bankservice:BankService, private router: Router, private authservice:AuthService) { }
  
  ngOnInit(): void {
    this.bankservice.getUserAccount().subscribe((data :any)=>{
    this.bankservice.accnme = data[0].fname;  
    this.accounts = data;
    this.authservice.isValidUser = true;
    console.log(this.accounts);
  });
  }

}

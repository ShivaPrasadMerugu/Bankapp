import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-viewaccount',
  templateUrl: './viewaccount.component.html',
  styleUrls: ['./viewaccount.component.css']
})
export class ViewaccountComponent implements OnInit {
  accounts :any;
  constructor(private bankservice:BankService,private authservice:AuthService) { }
  
  ngOnInit(): void {
   this.bankservice.viewAccountinfo().subscribe((data :any)=>{
   this.accounts = data;
   this.authservice.isAdminLoggedin = true;
   console.log(this.accounts);
  });
  }

}

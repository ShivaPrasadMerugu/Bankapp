import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-ministatement',
  templateUrl: './ministatement.component.html',
  styleUrls: ['./ministatement.component.css']
})
export class MinistatementComponent implements OnInit {

  sentdata:any;
  rxdata:any;
  constructor(private bankservice:BankService,private authservice:AuthService) { }

  ngOnInit(): void {
    this.bankservice.getTransacations().subscribe((data :any)=>{
      this.sentdata = data.filter(x=>x.srcaccnme === this.bankservice.accnme);
      this.rxdata = data.filter(x=>x.destaccnme === this.bankservice.accnme);
      this.authservice.isValidUser = true;
    });
  }

}

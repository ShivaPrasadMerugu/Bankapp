import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NewaccountComponent } from './newaccount/newaccount.component';
import { ManageaccountsComponent } from './manageaccounts/manageaccounts.component';
import { EditaccountComponent } from './editaccount/editaccount.component';
import { ViewaccountComponent } from './viewaccount/viewaccount.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { MyaccountComponent } from './myaccount/myaccount.component';
import { MinistatementComponent } from './ministatement/ministatement.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NavigationComponent } from './navigation/navigation.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { HttpClientModule } from '@angular/common/http';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NewaccountComponent,
    ManageaccountsComponent,
    EditaccountComponent,
    ViewaccountComponent,
    TransactionsComponent,
    FundtransferComponent,
    MyaccountComponent,
    MinistatementComponent,
    PagenotfoundComponent,
    NavigationComponent,
    UserloginComponent,
    AdminloginComponent,
    LoadingSpinnerComponent,
    AboutusComponent,
    ContactusComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

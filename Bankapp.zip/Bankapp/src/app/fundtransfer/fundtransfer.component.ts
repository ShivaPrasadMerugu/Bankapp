import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { account } from 'src/models/account.model';
import { fund } from 'src/models/fund.model';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {
  signupForm:FormGroup;
  error:string = null;
  accounts:any;
  srcaccount:account;
  response:string;
  showfunderr:boolean=false;
  constructor(private authservice:AuthService, public router: Router,private bankservice:BankService) { }

  ngOnInit(): void {
    this.bankservice.getUserAccounts().subscribe((data :any)=>{
      this.srcaccount = data.filter(x=>x.email === this.bankservice.userEmail);
      data = data.filter(x=>x.email != this.bankservice.userEmail);
      this.accounts = data;
      this.authservice.isValidUser = true;
      console.log(this.accounts);
    });
    this.signupForm =new FormGroup({
      'amount':new FormControl(null,Validators.required),
      'destaccnbr':new FormControl(null,Validators.required),
      'srcaccnbr':new FormControl(null),
      'srcaccnme':new FormControl(null),
      'destaccnme':new FormControl(null)
    })
  }
  Checkbalance(event:any){
     if (Number(event.target.value) > Number(this.srcaccount[0].balance))
     {
        this.showfunderr=true;
        console.log('error');
     }
     else{
        this.showfunderr=false;
     }
     console.log(event.target.value);
  }
  InitiateTransfer(form:fund){     
     if (!this.signupForm.valid || this.showfunderr){
       console.log('invalid operation');
       return;
     }
     debugger;
     let srcaccount:account = this.srcaccount;
     srcaccount[0].balance = srcaccount[0].balance - (Number(this.signupForm.get('amount').value));
     let destaccount:account = this.accounts.filter(x=>x.accnbr === Number(this.signupForm.get('destaccnbr').value));
     destaccount[0].balance = destaccount[0].balance + (Number(this.signupForm.get('amount').value));
     form.srcaccnbr = srcaccount[0].accnbr;
     form.srcaccnme = srcaccount[0].fname;
     form.destaccnme = destaccount[0].fname;
     form.date =  new Date().toDateString();
     console.log(form,srcaccount,destaccount);
     this.response = this.bankservice.transferFunds(srcaccount,destaccount,form);
     if (this.response == "success"){
     alert("Amount Transferred Successfully.");
     this.authservice.isValidUser = true;
     const redirectUrl = '/transactions';
     this.router.navigate([redirectUrl]);
     }
  }
}

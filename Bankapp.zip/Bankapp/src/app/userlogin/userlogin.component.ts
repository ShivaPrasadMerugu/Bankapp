import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { login } from 'src/models/login.model';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  signupForm:FormGroup;
  isLoading:boolean = false;
  error:string = null;
  constructor(private authservice:AuthService, public router: Router,private bankservice:BankService) { }

  ngOnInit(): void {
    this.signupForm =new FormGroup({
      'email':new FormControl(null,Validators.required),
      'password':new FormControl(null,Validators.required),
      'valuecheck':new FormControl(null,Validators.required)
    })
  }
  CreateAccount(logindata:login){
    if (!this.signupForm.valid){
      console.log('Invalid form');
      return;
    }
    this.isLoading = true;
    this.authservice.OnCreatePost(logindata).subscribe(resdata => {
      this.isLoading=false;
      this.authservice.isValidUser = true;
      this.bankservice.userEmail = logindata.email;
      localStorage.setItem("usertoken",resdata.idToken);
      localStorage.setItem("token",resdata.idToken);
      const redirectUrl = '/myaccount';
      this.router.navigate([redirectUrl]);
    },
    error => {
      console.log(error);
      this.error = 'The user login credentials are invalid';
      this.isLoading=false;
    }
    );
   this.signupForm.reset();
  }

}

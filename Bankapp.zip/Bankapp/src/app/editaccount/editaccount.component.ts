import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, MinLengthValidator, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { $ } from 'protractor';
import { account } from 'src/models/account.model';
import { AuthService } from 'src/services/auth.service';
import { BankService } from 'src/services/bank.service';

@Component({
  selector: 'app-editaccount',
  templateUrl: './editaccount.component.html',
  styleUrls: ['./editaccount.component.css']
})
export class EditaccountComponent implements OnInit {
  accounts:any;
  editAccountForm:FormGroup;
  accountnbr :number = 0;
  submitted:boolean=false;
  isLoading:boolean = false;
  error:string = null;
  response:string;
  showdepositbtn :boolean = true;
  constructor(private bankservice:BankService, public router: Router, private authservice:AuthService) { 
  }

  ngOnInit(): void {
    this.editAccountForm =new FormGroup({
      'balance':new FormControl(null,Validators.required),
      'fname':new FormControl(null,Validators.required),
      'lname':new FormControl(null,Validators.required),
      'dob':new FormControl(null,Validators.required),
      'acctype':new FormControl(null,Validators.required),
      'PAddrs':new FormControl(null,Validators.required),
      'CAddrs':new FormControl(null,Validators.required),
      'profession':new FormControl(null,Validators.required),
      'income':new FormControl(null,Validators.required),
      'email':new FormControl(null,Validators.required),
      'mobile':new FormControl(null,Validators.required)
    });
    this.bankservice.viewAccountinfo().subscribe((data :any)=>{
      this.accounts = data;
      console.log(this.accounts);
      let profile = this.accounts;
      this.editAccountForm.patchValue({
      fname:profile.fname,
      lname:profile.lname,
      email:profile.email,
      mobile:profile.mobile,
      PAddrs:profile.PAddrs,
      CAddrs:profile.CAddrs,
      income:profile.income,
      profession:profile.profession,
      acctype:profile.acctype,
      dob:profile.dob,
      balance:profile.balance
    })
    });
    
  }

  SaveAccount(accountform:account){
    this.isLoading = true;
    accountform.balance = this.accounts.balance;
    accountform.optgender = this.accounts.optgender;
    accountform.accnbr = this.accounts.accnbr;
    debugger;
    console.log(accountform);
    this.submitted = true;
    if (!this.editAccountForm.valid){
      return;
    }
    if (!this.showdepositbtn){
      accountform.balance = this.editAccountForm.get('balance').value + this.accounts.balance;
    }
    this.bankservice.updateAccount(accountform).subscribe(resdata => {
      this.authservice.isAdminLoggedin = true;
      this.isLoading=false;
    },
    error => {
      console.log(error);
      this.error = 'An error occurred while processing your request';
      this.isLoading=false;
    }
    );
   const redirectUrl = '/manageaccounts';
   this.router.navigate([redirectUrl]);
   this.editAccountForm.reset();
  }
 
  
  ShowInputBox(){
    this.showdepositbtn = false;
  }
}

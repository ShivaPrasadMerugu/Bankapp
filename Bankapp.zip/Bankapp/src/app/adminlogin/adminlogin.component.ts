import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BankService } from 'src/services/bank.service';
import { login } from 'src/models/login.model';
import { AuthService } from 'src/services/auth.service';
import { Observable } from 'rxjs';
import { AuthResponseData } from 'src/models/loginresponse.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  signupForm:FormGroup;
  isLoading:boolean = false;
  error:string = null;
  constructor(private authservice:AuthService, public router: Router) { }

  ngOnInit(): void {
    this.signupForm =new FormGroup({
      'email':new FormControl(null,Validators.required),
      'password':new FormControl(null,Validators.required),
      'valuecheck':new FormControl(null,Validators.required)
    })
  }
  CreateAccount(logindata:login){
    if (!this.signupForm.valid){
      console.log('Invalid form');
      return;
    }
    this.isLoading = true;
    this.authservice.OnCreatePost(logindata).subscribe(resdata => {
      localStorage.setItem("token",resdata.idToken);
      this.authservice.getadmin(logindata).subscribe(checkadmin=>{
        debugger;
         if (logindata.email === checkadmin["-MaU2pOWKSq-A8EdXDi0"].email && logindata.password === checkadmin["-MaU2pOWKSq-A8EdXDi0"].password){
          this.isLoading=false;
          this.authservice.isAdminLoggedin = true;
          const redirectUrl = '/manageaccounts';
          this.router.navigate([redirectUrl]);
         }
         else{
          this.error = 'Please enter the valid admin credentials';
          this.isLoading=false;
         }
      });
     
    },
    error => {
      console.log(error);
      this.error = 'Please enter the valid admin credentials';
      this.isLoading=false;
    }
    );
   this.signupForm.reset();
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { login } from '../models/login.model'
import { environment } from 'src/environments/environment';
import { AuthResponseData } from 'src/models/loginresponse.model';
import { admin } from 'src/models/admin.model';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthService {
isAdminLoggedin :boolean = false;
isValidUser :boolean = false;
constructor(private http:HttpClient) { }
OnCreatePost(postData:login){
    //.json in url is a firebase requirement and it is not part of angular
    return this.http.post<AuthResponseData>("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + environment.firebaseAPIKey,{
        email : postData.email,
        password : postData.password,
        returnSecureToken : true
    }
    );
}
getadmin(data:login){
    console.log(data);
    return this.http.get("https://abc-bank-103ed-default-rtdb.firebaseio.com/admin.json?auth="  + localStorage.getItem("token")).pipe(map(resdata =>{
        return resdata;
    }));
}

}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { account } from '../models/account.model'
import { AuthResponseData } from 'src/models/loginresponse.model';
import { forkJoin } from 'rxjs';
import {delay, map, tap} from "rxjs/operators";
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { fund } from 'src/models/fund.model';
import { admin } from 'src/models/admin.model';

@Injectable({ providedIn: 'root' })
export class BankService {
viewAccount : string = "";
userEmail:string="";
accnme:string="";
constructor(private http:HttpClient, public router: Router) { }
addNewAccount(postData:account){
    
//    return( this.http.post<AuthResponseData>("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + environment.firebaseAPIKey,{
//         email : postData.email,
//         password : postData.password,
//         returnSecureToken : true
//     }).pipe(map (resdata=>{
//         console.log(resdata);
//         //localStorage.setItem()
//         debugger;
//         postData.userId = resdata.localId;
//         return this.http.post<{name:string}>("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank.json?auth=" + resdata.idToken,postData).pipe(map (postdata=>{
//            console.log(postData);
//         }));
//     })))
        this.http.post<AuthResponseData>("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + environment.firebaseAPIKey,{
            email : postData.email,
            password : postData.password,
            returnSecureToken : true
        }).subscribe(resdata=>{
            debugger;
            console.log(resdata);
            postData.userId = resdata.localId;
            this.http.post<{name:string}>("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank.json?auth=" + resdata.idToken,postData).subscribe(postdata=>{
            })
        });
        return "success";
    // const requestArray = [];
    // requestArray.push(req1);
    // requestArray.push(req2);
    // return forkJoin(requestArray); 
}
getUserAccounts(){
    //delay(4000);
    return this.http.get("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank.json?auth=" + localStorage.getItem("token")).pipe(map(resdata =>{
    const arr:account[]= [];
    for(const key in resdata)
    {
         if(resdata.hasOwnProperty(key)){
         arr.push({...resdata[key],id:key});
         }
    }
    return arr;
    }));
}
getUserAccount(){
    return this.http.get("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank.json?auth=" + localStorage.getItem("usertoken")).pipe(map(resdata =>{
    const arr:account[]= [];
    for(const key in resdata)
    {
         if(resdata.hasOwnProperty(key)){
         arr.push({...resdata[key],id:key});
         }
    }
    return arr.filter(x=>x.email === this.userEmail);
    }));
}
viewAccountinfo(){
    return this.http.get("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank/" + this.viewAccount +".json?auth=" + localStorage.getItem("token")).pipe(map(resdata =>{
    return resdata;
    }));
}
updateAccount(putdata:account){
    return this.http.patch<{name:string}>("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank/" + this.viewAccount +".json?auth=" + localStorage.getItem("token"),putdata).pipe(map(resdata =>{
    }));
}
transferFunds(srcaccount:account,destaccount:account,fundform:fund){
    console.log(srcaccount[0].id,destaccount[0].id,fundform);
    this.http.patch<{name:string}>("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank/" + srcaccount[0].id +".json?auth=" + localStorage.getItem("token"),srcaccount[0]).subscribe(srcdata =>{
        this.http.patch<{name:string}>("https://abc-bank-103ed-default-rtdb.firebaseio.com/abcbank/" + destaccount[0].id +".json?auth=" + localStorage.getItem("token"),destaccount[0]).subscribe(destdata =>{
            this.http.post<{name:string}>("https://abc-bank-103ed-default-rtdb.firebaseio.com/Transactions.json?auth=" + localStorage.getItem("token"),fundform).subscribe(postdata=>{
            })
        })
    });
    delay(8000);
    return "success";
}
getTransacations(){
    return this.http.get("https://abc-bank-103ed-default-rtdb.firebaseio.com/Transactions.json?auth=" + localStorage.getItem("token")).pipe(map(resdata =>{
        const arr:fund[]= [];
        for(const key in resdata)
        {
             if(resdata.hasOwnProperty(key)){
             arr.push({...resdata[key],id:key});
             }
        }
        return arr;
        }));
}

}
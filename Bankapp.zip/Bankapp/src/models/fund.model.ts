export interface fund{
    srcaccnme:string;
    srcaccnbr:number;
    destaccnme:string;
    destaccnbr:number;
    amount:number;
    date:string;
}
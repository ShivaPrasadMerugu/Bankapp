export interface login{
    email:string;
    password:string;
    //isadmin:boolean;
  }
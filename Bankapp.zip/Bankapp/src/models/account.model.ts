export interface account{
    firstname:string;
    lastname:string;
    dateofbirth:string;
    optgender:string;
    email:string;
    mobile:number;
    profession:string;
    Ann_income:number;
    presentaddrs:string;
    permanentaddrs:string;
    acctype:string;
    accnbr:number;
    password:number;
    balance:number;
    userId:string;
}
export interface admin{
    username:string;
    password:string;
    //isadmin:boolean;
  }